<?php

/* default/index.html.twig */
class __TwigTemplate_095f9ab9fbf416d7bf2e9cbc3febdef1fc45641179f49a1cf2de25c5dfc468f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b90dc80fe059a49c61ff564aa56f79a259d55eaa7c2b8b7fa28f50d98dad93f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b90dc80fe059a49c61ff564aa56f79a259d55eaa7c2b8b7fa28f50d98dad93f2->enter($__internal_b90dc80fe059a49c61ff564aa56f79a259d55eaa7c2b8b7fa28f50d98dad93f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b90dc80fe059a49c61ff564aa56f79a259d55eaa7c2b8b7fa28f50d98dad93f2->leave($__internal_b90dc80fe059a49c61ff564aa56f79a259d55eaa7c2b8b7fa28f50d98dad93f2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d0d3f5cbcb7496ed9286e6424ce1b8add2f7ed41992e65ccba772cd3ac035418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0d3f5cbcb7496ed9286e6424ce1b8add2f7ed41992e65ccba772cd3ac035418->enter($__internal_d0d3f5cbcb7496ed9286e6424ce1b8add2f7ed41992e65ccba772cd3ac035418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"row carousel-holder\">

        <div class=\"col-md-12\">
            <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
                <ol class=\"carousel-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                </ol>
                <div class=\"carousel-inner\">
                    <div class=\"item active\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                    <div class=\"item\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                    <div class=\"item\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                </div>
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" data-slide=\"prev\">
                    <span class=\"glyphicon glyphicon-chevron-left\"></span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" data-slide=\"next\">
                    <span class=\"glyphicon glyphicon-chevron-right\"></span>
                </a>
            </div>
        </div>

    </div>

   
        ";
        // line 37
        $context["row"] = 0;
        // line 38
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 39
            echo "            ";
            if (((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")) == 0)) {
                echo " 
                <div class=\"row\">
            ";
            }
            // line 42
            echo "        <div class=\"col-sm-4 col-lg-4 col-md-4\">
            
            <div class=\"thumbnail\">
                ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["p"], "images", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 46
                echo "                    ";
                if (($this->getAttribute($context["i"], "ShowDefault", array()) == 1)) {
                    // line 47
                    echo "                        <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("uploads/brochures/" . $this->getAttribute($context["i"], "file", array()))), "my_thumb"), "html", null, true);
                    echo "\" />
                    ";
                }
                // line 49
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 50
            echo "                <div class=\"caption\">   
                    <h4 class=\"pull-right\">";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["p"], "post", array()), "price", array()), "html", null, true);
            echo "</h4>
                    <h4><a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_view", array("id" => $this->getAttribute($this->getAttribute($context["p"], "post", array()), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["p"], "post", array()), "title", array()), "html", null, true);
            echo "</a>
                    </h4>
                    ";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["p"], "post", array()), "description", array()), "html", null, true);
            echo "
                </div>

                <div class=\"ratings\">
                    <p class=\"pull-right\">15 reviews</p>
                    <p>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                    </p>
                </div>
            </div>
        </div>
        ";
            // line 69
            $context["row"] = ((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")) + 1);
            // line 70
            echo "        ";
            if (((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")) == 3)) {
                // line 71
                echo "           ";
                $context["row"] = 0;
                echo " 
           </div>
        ";
            }
            // line 74
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "    </div>

";
        
        $__internal_d0d3f5cbcb7496ed9286e6424ce1b8add2f7ed41992e65ccba772cd3ac035418->leave($__internal_d0d3f5cbcb7496ed9286e6424ce1b8add2f7ed41992e65ccba772cd3ac035418_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 75,  157 => 74,  150 => 71,  147 => 70,  145 => 69,  127 => 54,  120 => 52,  116 => 51,  113 => 50,  107 => 49,  101 => 47,  98 => 46,  94 => 45,  89 => 42,  82 => 39,  77 => 38,  75 => 37,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"row carousel-holder\">

        <div class=\"col-md-12\">
            <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
                <ol class=\"carousel-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                </ol>
                <div class=\"carousel-inner\">
                    <div class=\"item active\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                    <div class=\"item\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                    <div class=\"item\">
                        <img class=\"slide-image\" src=\"http://placehold.it/800x300\" alt=\"\">
                    </div>
                </div>
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" data-slide=\"prev\">
                    <span class=\"glyphicon glyphicon-chevron-left\"></span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" data-slide=\"next\">
                    <span class=\"glyphicon glyphicon-chevron-right\"></span>
                </a>
            </div>
        </div>

    </div>

   
        {% set row=0 %}
        {% for p in post %}
            {% if row == 0 %} 
                <div class=\"row\">
            {% endif %}
        <div class=\"col-sm-4 col-lg-4 col-md-4\">
            
            <div class=\"thumbnail\">
                {% for i in p.images %}
                    {%  if i.ShowDefault == 1 %}
                        <img src=\"{{ asset('uploads/brochures/' ~ i.file) | imagine_filter('my_thumb') }}\" />
                    {%  endif %}
                {%  endfor %}
                <div class=\"caption\">   
                    <h4 class=\"pull-right\">{{ p.post.price }}</h4>
                    <h4><a href=\"{{  path('post_view', {'id': p.post.id}) }}\">{{ p.post.title }}</a>
                    </h4>
                    {{ p.post.description }}
                </div>

                <div class=\"ratings\">
                    <p class=\"pull-right\">15 reviews</p>
                    <p>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                        <span class=\"glyphicon glyphicon-star\"></span>
                    </p>
                </div>
            </div>
        </div>
        {% set row = row + 1 %}
        {% if row == 3 %}
           {% set row = 0 %} 
           </div>
        {% endif %}
        {% endfor %}
    </div>

{% endblock %}

", "default/index.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/default/index.html.twig");
    }
}
