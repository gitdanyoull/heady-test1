<?php

/* post/category.html.twig */
class __TwigTemplate_aa76e31bc23347d784e2df2bf46b7804f09e319398a00a521465ff00cbed8a8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "post/category.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60a7f955132cc50cd9dd9003d2b350c776eb9606e77989b7b74fed92dadc2d53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60a7f955132cc50cd9dd9003d2b350c776eb9606e77989b7b74fed92dadc2d53->enter($__internal_60a7f955132cc50cd9dd9003d2b350c776eb9606e77989b7b74fed92dadc2d53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/category.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_60a7f955132cc50cd9dd9003d2b350c776eb9606e77989b7b74fed92dadc2d53->leave($__internal_60a7f955132cc50cd9dd9003d2b350c776eb9606e77989b7b74fed92dadc2d53_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_56cbeff83656f937f04ae9b2d9d05626a1a27fa7d4ecfd33686fd3de8f36c4fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56cbeff83656f937f04ae9b2d9d05626a1a27fa7d4ecfd33686fd3de8f36c4fe->enter($__internal_56cbeff83656f937f04ae9b2d9d05626a1a27fa7d4ecfd33686fd3de8f36c4fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "        <div class=\"row\">
            <div class=\"col-sm-12\">
                <button class=\"btn btn-success pull-right\" onclick=\"location.href='";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_new");
        echo "';\">Add Post</button><br /><br />
            </div>
            <div class=\"col-sm-12\">

        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
            // line 11
            echo "            <div class=\"alert alert-success\">
                <strong>Success!</strong> Indicates a successful or positive action.
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "        <table class=\"table table-striped\">
            ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 17
            echo "                <tr>
                    <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "id", array()), "html", null, true);
            echo "<a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_edit", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo "\">
                            ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "title", array()), "html", null, true);
            echo "</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "        </table>
            </div>
        </div>
";
        
        $__internal_56cbeff83656f937f04ae9b2d9d05626a1a27fa7d4ecfd33686fd3de8f36c4fe->leave($__internal_56cbeff83656f937f04ae9b2d9d05626a1a27fa7d4ecfd33686fd3de8f36c4fe_prof);

    }

    // line 28
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cf3559bd7102e6d66059cb666cd3cfc31f897b956df4bab2ca2b5a301cb53322 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf3559bd7102e6d66059cb666cd3cfc31f897b956df4bab2ca2b5a301cb53322->enter($__internal_cf3559bd7102e6d66059cb666cd3cfc31f897b956df4bab2ca2b5a301cb53322_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 29
        echo "
";
        
        $__internal_cf3559bd7102e6d66059cb666cd3cfc31f897b956df4bab2ca2b5a301cb53322->leave($__internal_cf3559bd7102e6d66059cb666cd3cfc31f897b956df4bab2ca2b5a301cb53322_prof);

    }

    public function getTemplateName()
    {
        return "post/category.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 29,  101 => 28,  91 => 23,  81 => 19,  75 => 18,  72 => 17,  68 => 16,  65 => 15,  56 => 11,  52 => 10,  45 => 6,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <button class=\"btn btn-success pull-right\" onclick=\"location.href='{{ path('post_new') }}';\">Add Post</button><br /><br />
            </div>
            <div class=\"col-sm-12\">

        {% for msg in app.session.flashBag.get('success') %}
            <div class=\"alert alert-success\">
                <strong>Success!</strong> Indicates a successful or positive action.
            </div>
        {% endfor %}
        <table class=\"table table-striped\">
            {% for p in post %}
                <tr>
                    <td>{{p.id}}<a href=\"{{ path('post_edit', {'id': p.id}) }}\">
                            {{p.title}}</a>
                    </td>
                </tr>
            {% endfor %}
        </table>
            </div>
        </div>
{% endblock %}

{% block stylesheets %}

{% endblock %}
", "post/category.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/post/category.html.twig");
    }
}
