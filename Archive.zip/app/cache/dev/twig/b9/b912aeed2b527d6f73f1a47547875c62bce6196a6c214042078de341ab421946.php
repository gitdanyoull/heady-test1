<?php

/* menu.html.twig */
class __TwigTemplate_53fa56167ca2be5bb3c5e8cad3addcb42a836da7d4bdc90155b3b37ac27a7032 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'menu' => array($this, 'block_menu'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_738e58cc7b254bc2fd2a5a87ab70a02523e815cc129443eda799b930bfeca94b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_738e58cc7b254bc2fd2a5a87ab70a02523e815cc129443eda799b930bfeca94b->enter($__internal_738e58cc7b254bc2fd2a5a87ab70a02523e815cc129443eda799b930bfeca94b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "menu.html.twig"));

        // line 1
        echo " ";
        $this->displayBlock('menu', $context, $blocks);
        
        $__internal_738e58cc7b254bc2fd2a5a87ab70a02523e815cc129443eda799b930bfeca94b->leave($__internal_738e58cc7b254bc2fd2a5a87ab70a02523e815cc129443eda799b930bfeca94b_prof);

    }

    public function block_menu($context, array $blocks = array())
    {
        $__internal_c874f9e26ee7cc0ff7bde8e39beaed1a23205c100d626a9f0ae8f0a058c0068d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c874f9e26ee7cc0ff7bde8e39beaed1a23205c100d626a9f0ae8f0a058c0068d->enter($__internal_c874f9e26ee7cc0ff7bde8e39beaed1a23205c100d626a9f0ae8f0a058c0068d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 2
        echo "    <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category", array("category" => "concentrate-bubblers"));
        echo "\" class=\"list-group-item\">Bubblers</a>
    <a href=\"";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category", array("category" => "accesories"));
        echo "\" class=\"list-group-item\">Accessories</a> 
    <a href=\"";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category", array("category" => "water-pipes"));
        echo "\" class=\"list-group-item\">Waterpipes</a> 
    <a href=\"";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category", array("category" => "non-functional"));
        echo "\" class=\"list-group-item\">Non-Functional</a> 
";
        
        $__internal_c874f9e26ee7cc0ff7bde8e39beaed1a23205c100d626a9f0ae8f0a058c0068d->leave($__internal_c874f9e26ee7cc0ff7bde8e39beaed1a23205c100d626a9f0ae8f0a058c0068d_prof);

    }

    public function getTemplateName()
    {
        return "menu.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  49 => 5,  45 => 4,  41 => 3,  36 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source(" {% block menu %}
    <a href=\"{{ path('category',{'category':'concentrate-bubblers'}) }}\" class=\"list-group-item\">Bubblers</a>
    <a href=\"{{ path('category',{'category':'accesories'}) }}\" class=\"list-group-item\">Accessories</a> 
    <a href=\"{{ path('category',{'category':'water-pipes'}) }}\" class=\"list-group-item\">Waterpipes</a> 
    <a href=\"{{ path('category',{'category':'non-functional'}) }}\" class=\"list-group-item\">Non-Functional</a> 
{% endblock %}", "menu.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/menu.html.twig");
    }
}
