<?php

/* post/form.html.twig */
class __TwigTemplate_f77327ae95dec397f5cbe5bb3357fb3b552b9124989c8b2347fe4115182fe30c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "post/form.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_384522c3982c8e571d37e5ef929979c527b4e60afe8f9b14fe8cc8eff4f49dc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_384522c3982c8e571d37e5ef929979c527b4e60afe8f9b14fe8cc8eff4f49dc1->enter($__internal_384522c3982c8e571d37e5ef929979c527b4e60afe8f9b14fe8cc8eff4f49dc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_384522c3982c8e571d37e5ef929979c527b4e60afe8f9b14fe8cc8eff4f49dc1->leave($__internal_384522c3982c8e571d37e5ef929979c527b4e60afe8f9b14fe8cc8eff4f49dc1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1bfcfaec2dd58df30bd0f857ed2b5f96a045fbb05749f73c557d0dc73975d2eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bfcfaec2dd58df30bd0f857ed2b5f96a045fbb05749f73c557d0dc73975d2eb->enter($__internal_1bfcfaec2dd58df30bd0f857ed2b5f96a045fbb05749f73c557d0dc73975d2eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

    <div class=\"col-sm-12 col-lg-12 col-md-12\">
        <ol class=\"breadcrumb\">
            <li class=\"breadcrumb-item\"><a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post");
        echo "\">Posts</a></li>
            <li class=\"breadcrumb-item\"><a href=\"#\">Library</a></li>
            <li class=\"breadcrumb-item active\">Data</li>
        </ol>
        <div class=\"thumbnail\">
            <div class=\"caption\">

            ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
            // line 16
            echo "                <div class=\"alert alert-success\">
                    <strong>Success!</strong> Indicates a successful or positive action.
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "
            ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row', array("label" => "Post Title"));
        echo "
                ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "artist", array()), 'row', array("label" => "Artist"));
        echo "
                ";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "artist_form", array()), 'row', array("label" => false));
        echo "
                ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'row', array("label" => "Price"));
        echo "
                ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "purchaseDate", array()), 'row', array("label" => "Purchase Date"));
        echo "
                ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'row', array("label" => "Description"));
        echo "  
                <button type=\"submit\" style=\"margin: 5px\" class=\"btn btn-default pull-right\" formnovalidate>Save</button>
            ";
        // line 29
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
            </div>
        </div>

        ";
        // line 33
        if ( !twig_test_empty($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))) {
            // line 34
            echo "
        <div class=\"thumbnail\">

            <div class=\"caption\">

                    <button class=\"btn btn-default pull-left\" style=\"margin: 5px\" onclick=\"javascript: window.location='";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_image", array("postId" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()), "imageId" => 1)), "html", null, true);
            echo "';\">Add Image</button>


                ";
            // line 42
            if ( !twig_test_empty((isset($context["images"]) ? $context["images"] : $this->getContext($context, "images")))) {
                // line 43
                echo "
                    <table class=\"table table-striped\">
                        ";
                // line 45
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["images"]) ? $context["images"] : $this->getContext($context, "images")));
                foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                    // line 46
                    echo "                            <tr>
                                <td>
                                    ";
                    // line 48
                    echo twig_escape_filter($this->env, $this->getAttribute($context["i"], "name", array()), "html", null, true);
                    echo "
                                </td>
                                <td>
                                    <input class=\"default_image\" data-value=\"";
                    // line 51
                    echo twig_escape_filter($this->env, $this->getAttribute($context["i"], "imageId", array()), "html", null, true);
                    echo "\" type=\"radio\" name=\"default_image\" ";
                    if (($this->getAttribute($context["i"], "ShowDefault", array()) == "1")) {
                        echo " checked ";
                    }
                    echo "value=\"yes\" />
                                </td>
                                <td>
                                    <a href=\"";
                    // line 54
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_image", array("postId" => $this->getAttribute($context["i"], "postId", array()), "imageId" => $this->getAttribute($context["i"], "imageId", array()))), "html", null, true);
                    echo "\"><span class=\"glyphicon glyphicon-pencil\"></span></a>
                                    <a href=\"";
                    // line 55
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_image", array("postId" => $this->getAttribute($context["i"], "postId", array()), "imageId" => $this->getAttribute($context["i"], "imageId", array()))), "html", null, true);
                    echo "\" class=\"pull-right\"><span class=\"glyphicon glyphicon-trash\"></span></a>
                                </td>
                            </tr>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 59
                echo "                    </table>

                ";
            }
            // line 62
            echo "
                ";
            // line 63
            echo             $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["image"]) ? $context["image"] : $this->getContext($context, "image")), 'form_start');
            echo "
                    ";
            // line 64
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["image"]) ? $context["image"] : $this->getContext($context, "image")), "imageId", array()), 'row', array("attr" => array("class" => "default_id")));
            echo "
                    ";
            // line 65
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["image"]) ? $context["image"] : $this->getContext($context, "image")), "showDefault", array()), 'row', array("attr" => array("class" => "default_note")));
            echo "
                ";
            // line 66
            echo             $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["image"]) ? $context["image"] : $this->getContext($context, "image")), 'form_end');
            echo "

            </div>
    </div>

        ";
        }
        // line 72
        echo "
";
        
        $__internal_1bfcfaec2dd58df30bd0f857ed2b5f96a045fbb05749f73c557d0dc73975d2eb->leave($__internal_1bfcfaec2dd58df30bd0f857ed2b5f96a045fbb05749f73c557d0dc73975d2eb_prof);

    }

    // line 75
    public function block_script($context, array $blocks = array())
    {
        $__internal_331ec39a0f7478964f5f3fdf35087e66398f513855ff8d2887dfcb79a3b215cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_331ec39a0f7478964f5f3fdf35087e66398f513855ff8d2887dfcb79a3b215cf->enter($__internal_331ec39a0f7478964f5f3fdf35087e66398f513855ff8d2887dfcb79a3b215cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "script"));

        // line 76
        echo "    <script>
        \$(document).ready( function() {
            var toggleArtistForm = function () {
                var \$form_group = \$('#post_form_artist_form').parent();
                var selectValue = \$('#post_form_artist').val();
                if(!selectValue) {
                  \$form_group.show();
                }
                else {
                  \$form_group.hide();
                }
            };
            \$('#post_form_artist').on('change', toggleArtistForm);
            toggleArtistForm();


            \$('input[type=radio]').click( function() {
                \$('#set_image_form_imageId').val( \$(this).attr(\"data-value\")  );
                var form = \$('form[name=\"set_image_form\"]').serializeArray();

                \$.ajax( {
                    type: \"POST\",
                    url: \"";
        // line 98
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("set_image");
        echo "\",
                    data: {
                        'form': form
                    },
                    success: function( response ) {
                        console.log( response );
                        \$.growl.notice({
                            title: \"Growl\",
                            message: \"Default picture assigned successfully\"
                        });
                    },
                    error: function(jqXHR, textStatus, errorThrown) {

                        console.log(\"AJAX error: \" + textStatus + ' : ' + errorThrown);
                    }
                } );
            } );

        } );

    </script>
";
        
        $__internal_331ec39a0f7478964f5f3fdf35087e66398f513855ff8d2887dfcb79a3b215cf->leave($__internal_331ec39a0f7478964f5f3fdf35087e66398f513855ff8d2887dfcb79a3b215cf_prof);

    }

    public function getTemplateName()
    {
        return "post/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  235 => 98,  211 => 76,  205 => 75,  197 => 72,  188 => 66,  184 => 65,  180 => 64,  176 => 63,  173 => 62,  168 => 59,  158 => 55,  154 => 54,  144 => 51,  138 => 48,  134 => 46,  130 => 45,  126 => 43,  124 => 42,  118 => 39,  111 => 34,  109 => 33,  102 => 29,  97 => 27,  93 => 26,  89 => 25,  85 => 24,  81 => 23,  77 => 22,  73 => 21,  70 => 20,  61 => 16,  57 => 15,  47 => 8,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}


    <div class=\"col-sm-12 col-lg-12 col-md-12\">
        <ol class=\"breadcrumb\">
            <li class=\"breadcrumb-item\"><a href=\"{{ path('post') }}\">Posts</a></li>
            <li class=\"breadcrumb-item\"><a href=\"#\">Library</a></li>
            <li class=\"breadcrumb-item active\">Data</li>
        </ol>
        <div class=\"thumbnail\">
            <div class=\"caption\">

            {% for msg in app.session.flashBag.get('success') %}
                <div class=\"alert alert-success\">
                    <strong>Success!</strong> Indicates a successful or positive action.
                </div>
            {% endfor %}

            {{ form_start(form) }}
                {{ form_row(form.title,{'label':'Post Title'}) }}
                {{ form_row(form.artist,{'label':'Artist'}) }}
                {{ form_row(form.artist_form,{'label': false}) }}
                {{ form_row(form.price,{'label':'Price'}) }}
                {{ form_row(form.purchaseDate,{'label':'Purchase Date'}) }}
                {{ form_row(form.description,{'label':'Description'}) }}  
                <button type=\"submit\" style=\"margin: 5px\" class=\"btn btn-default pull-right\" formnovalidate>Save</button>
            {{ form_end(form) }}
            </div>
        </div>

        {% if post.id is not empty %}

        <div class=\"thumbnail\">

            <div class=\"caption\">

                    <button class=\"btn btn-default pull-left\" style=\"margin: 5px\" onclick=\"javascript: window.location='{{ path('add_image', {'postId': post.id, 'imageId': 1}) }}';\">Add Image</button>


                {% if images is not empty %}

                    <table class=\"table table-striped\">
                        {% for i in images %}
                            <tr>
                                <td>
                                    {{i.name}}
                                </td>
                                <td>
                                    <input class=\"default_image\" data-value=\"{{ i.imageId }}\" type=\"radio\" name=\"default_image\" {% if i .ShowDefault == '1' %} checked {% endif  %}value=\"yes\" />
                                </td>
                                <td>
                                    <a href=\"{{ path('edit_image', {'postId': i.postId,'imageId': i.imageId}) }}\"><span class=\"glyphicon glyphicon-pencil\"></span></a>
                                    <a href=\"{{ path('delete_image', {'postId': i.postId,'imageId': i.imageId}) }}\" class=\"pull-right\"><span class=\"glyphicon glyphicon-trash\"></span></a>
                                </td>
                            </tr>
                        {% endfor %}
                    </table>

                {% endif %}

                {{ form_start(image) }}
                    {{ form_row(image.imageId, { 'attr': {'class': 'default_id'} }) }}
                    {{ form_row(image.showDefault, { 'attr': {'class': 'default_note'} }) }}
                {{ form_end(image) }}

            </div>
    </div>

        {% endif %}

{% endblock %}

{% block script %}
    <script>
        \$(document).ready( function() {
            var toggleArtistForm = function () {
                var \$form_group = \$('#post_form_artist_form').parent();
                var selectValue = \$('#post_form_artist').val();
                if(!selectValue) {
                  \$form_group.show();
                }
                else {
                  \$form_group.hide();
                }
            };
            \$('#post_form_artist').on('change', toggleArtistForm);
            toggleArtistForm();


            \$('input[type=radio]').click( function() {
                \$('#set_image_form_imageId').val( \$(this).attr(\"data-value\")  );
                var form = \$('form[name=\"set_image_form\"]').serializeArray();

                \$.ajax( {
                    type: \"POST\",
                    url: \"{{ path('set_image') }}\",
                    data: {
                        'form': form
                    },
                    success: function( response ) {
                        console.log( response );
                        \$.growl.notice({
                            title: \"Growl\",
                            message: \"Default picture assigned successfully\"
                        });
                    },
                    error: function(jqXHR, textStatus, errorThrown) {

                        console.log(\"AJAX error: \" + textStatus + ' : ' + errorThrown);
                    }
                } );
            } );

        } );

    </script>
{% endblock %}

", "post/form.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/post/form.html.twig");
    }
}
