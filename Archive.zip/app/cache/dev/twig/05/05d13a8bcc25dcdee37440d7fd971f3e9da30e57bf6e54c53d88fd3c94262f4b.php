<?php

/* post/post.html.twig */
class __TwigTemplate_9a62c3ba43bce8f794d7fe44f665cbe26b9a17bc7807d75cd35c697833fc5aea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "post/post.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2b16b550b33a9dfd8967475524ca32a27636dfaf79fb1be722aba6472180912 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2b16b550b33a9dfd8967475524ca32a27636dfaf79fb1be722aba6472180912->enter($__internal_e2b16b550b33a9dfd8967475524ca32a27636dfaf79fb1be722aba6472180912_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/post.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e2b16b550b33a9dfd8967475524ca32a27636dfaf79fb1be722aba6472180912->leave($__internal_e2b16b550b33a9dfd8967475524ca32a27636dfaf79fb1be722aba6472180912_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_0e50b7f5d351d217e1f9efbae0c9a4920bd5730c1431149e4aa855103c938104 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e50b7f5d351d217e1f9efbae0c9a4920bd5730c1431149e4aa855103c938104->enter($__internal_0e50b7f5d351d217e1f9efbae0c9a4920bd5730c1431149e4aa855103c938104_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo " | Item | Online Market for Glass Pipes, Vaporizers, & More At WickedHeady
";
        
        $__internal_0e50b7f5d351d217e1f9efbae0c9a4920bd5730c1431149e4aa855103c938104->leave($__internal_0e50b7f5d351d217e1f9efbae0c9a4920bd5730c1431149e4aa855103c938104_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_d2400f063ada227a39ac71638c30af01ac7c243f38832ade21f380ea981cd452 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2400f063ada227a39ac71638c30af01ac7c243f38832ade21f380ea981cd452->enter($__internal_d2400f063ada227a39ac71638c30af01ac7c243f38832ade21f380ea981cd452_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "
    <!--IMAGE AREA-->
    <div class=\"col-sm-4 col-lg-4 col-md-4\">
        <div class=\"thumbnail\">
            ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["images"]) ? $context["images"] : $this->getContext($context, "images")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 14
            echo "                <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Liip\ImagineBundle\Templating\ImagineExtension')->filter($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("uploads/brochures/" . $this->getAttribute($context["i"], "file", array()))), "my_thumb"), "html", null, true);
            echo "\" style=\"margin-bottom: 4px\" />
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
        </div>
    </div>

    <div class=\"col-sm-8 col-lg-8 col-md-8\">

        <div class=\"thumbnail\">
            <span class=\"glyphicon glyphicon-bookmark\" style=\"top: -4px; left: 4px\"></span>
            <div class=\"caption\">

                <h4>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h4>
                <h4>\$";
        // line 27
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "price", array()), 2, ".", ","), "html", null, true);
        echo "</h4>
                
                <p>";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "description", array()), "html", null, true);
        echo "</p>
                
                <!--JAVASCRIPT TRIGGER TO SHOW OFFER FORM-->
                <btn type=\"button\" class=\"btn btn-danger pull-right hide\" id=\"hide_offer\" onclick=\"javascript: void(0);\">Submit an Offer</btn>

                <btn type=\"button\" class=\"btn btn-success pull-right\" id=\"submit_offer\" onclick=\"javascript: void(0);\">Submit an Offer</btn>

            </div>
        </div>

        <div class=\"thumbnail\">
            <div class=\"caption\" id=\"contact_form_div\" style=\"display: none \">
                ";
        // line 41
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), 'form_start');
        echo "
                ";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), 'widget');
        echo "
                <button type=\"submit\" style=\"margin-top: 5px\" class=\"btn btn-default\" formnovalidate>Save</button>
                ";
        // line 44
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), 'form_end');
        echo "

            </div>
            <div class=\"caption\" id=\"message_form_div\">
                ";
        // line 48
        if (twig_test_empty((isset($context["review"]) ? $context["review"] : $this->getContext($context, "review")))) {
            // line 49
            echo "                    ";
            echo             $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), 'form_start');
            echo "
                    ";
            // line 50
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), 'widget');
            echo "
                    <button type=\"submit\" style=\"margin-top: 5px\" class=\"btn btn-default\" formnovalidate>Save</button>
                    ";
            // line 52
            echo             $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), 'form_end');
            echo "
                    <div class=\"ratings\">
                        <div id=\"rateYo\" class=\"pull-left\"></div>
                    </div>
                    <div class=\"hide\">
                        <span id=\"review_title\"></span><br />
                            <span id=\"review_description\"></span>
                    </div>
                ";
        } else {
            // line 61
            echo "                    ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["review"]) ? $context["review"] : $this->getContext($context, "review")), "title", array()), "html", null, true);
            echo "<br />
                    ";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["review"]) ? $context["review"] : $this->getContext($context, "review")), "message", array()), "html", null, true);
            echo "
                    <div class=\"ratings\">
                        <div id=\"rateYo\" class=\"pull-left\"></div>
                    </div>
                ";
        }
        // line 67
        echo "            </div>
        </div>                 
        ";
        // line 69
        if ( !twig_test_empty((isset($context["messages"]) ? $context["messages"] : $this->getContext($context, "messages")))) {
            // line 70
            echo "        <div class=\"well\">                      
            <div class=\"caption\">                
 
                    ";
            // line 73
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["messages"]) ? $context["messages"] : $this->getContext($context, "messages")));
            foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
                if (($this->getAttribute($this->getAttribute($context["m"], "user", array()), "id", array()) != 1)) {
                    // line 74
                    echo "                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                ";
                    // line 76
                    if (($this->getAttribute($this->getAttribute($context["m"], "user", array()), "id", array()) != (isset($context["user_id"]) ? $context["user_id"] : $this->getContext($context, "user_id")))) {
                        // line 77
                        echo "                                    ";
                        $context["rate"] = $this->getAttribute($context["m"], "rating", array());
                        echo " 
                                    ";
                        // line 78
                        $context["empty"] = (5 - (isset($context["rate"]) ? $context["rate"] : $this->getContext($context, "rate")));
                        // line 79
                        echo "                                    ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["rate"]) ? $context["rate"] : $this->getContext($context, "rate"))));
                        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                            // line 80
                            echo "                                        <span class=\"glyphicon glyphicon-star\"></span>
                                    ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 82
                        echo "                                    ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["empty"]) ? $context["empty"] : $this->getContext($context, "empty"))));
                        foreach ($context['_seq'] as $context["_key"] => $context["e"]) {
                            if (((isset($context["rate"]) ? $context["rate"] : $this->getContext($context, "rate")) != 5)) {
                                // line 83
                                echo "                                        <span class=\"glyphicon glyphicon-star-empty\"></span>
                                     ";
                            }
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['e'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 85
                        echo "                                    ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "title", array()), "html", null, true);
                        echo "
                                    <span class=\"pull-right\"> ";
                        // line 86
                        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["m"], "tstamp", array()), "m/d/Y"), "html", null, true);
                        echo "</span>
                                    <p>";
                        // line 87
                        echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "message", array()), "html", null, true);
                        echo "
                                        <span class=\"glyphicon glyphicon-pencil pull-right\" id=\"message_comment \"></span></p>
                                ";
                    }
                    // line 90
                    echo "                            </div>
                        </div> 
                    ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 93
            echo "
            </div>

        </div>

                ";
        }
        // line 99
        echo "    </div>


";
        
        $__internal_d2400f063ada227a39ac71638c30af01ac7c243f38832ade21f380ea981cd452->leave($__internal_d2400f063ada227a39ac71638c30af01ac7c243f38832ade21f380ea981cd452_prof);

    }

    // line 104
    public function block_script($context, array $blocks = array())
    {
        $__internal_8bf00290a579f263bf4a7446d72dca9734ff30174dbc64836dbd0271182bb99f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bf00290a579f263bf4a7446d72dca9734ff30174dbc64836dbd0271182bb99f->enter($__internal_8bf00290a579f263bf4a7446d72dca9734ff30174dbc64836dbd0271182bb99f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "script"));

        // line 105
        echo "  
    <script>
        \$(document).ready( function() {

            //handle rating
            var isMobile = window.matchMedia(\"only screen and (max-width: 760px)\");

            if( !isMobile.matches )
            {
                \$(\"#rateYo\").rateYo({

                    rating: ";
        // line 116
        echo twig_escape_filter($this->env, ((array_key_exists("stars", $context)) ? (_twig_default_filter((isset($context["stars"]) ? $context["stars"] : $this->getContext($context, "stars")), 4)) : (4)), "html", null, true);
        echo ",
                    spacing: \"5px\",
                    readOnly: ";
        // line 118
        if (twig_test_empty((isset($context["review"]) ? $context["review"] : $this->getContext($context, "review")))) {
            echo " false ";
        } else {
            echo " true ";
        }
        echo ",

                }).on(\"rateyo.set\", function (e, data) {

                    \$('#message_form_rating').val(data.rating);
 

                    \$(\"#rateYo\").rateYo(\"option\", \"readOnly\", \"true\");
                    return false;   

                });

            }
            //handle hiding & showing forms
            \$('#leave_review').click(function (e){
                \$('#message_form_div').fadeOut( \"slow\", function() {
                    \$('#contact_form_div').fadeIn(\"slow\");
                });
            });
 
            \$('#switch_offer').click(function(){

                \$('#hide_offer').toggleClass('hide');
                \$('#submit_offer').toggleClass('hide');
                \$('#contact_form_div').fadeOut( \"slow\", function() {
                    \$('#message_form_div').fadeIn(\"slow\");
                });

            });

            \$('#submit_offer').click(function(){

                \$('#hide_offer').toggleClass('hide');
                \$('#submit_offer').toggleClass('hide');
                \$('#message_form_div').fadeOut( \"slow\", function() {
                    \$('#contact_form_div').fadeIn(\"slow\");
                });
                //window.location=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("offer_form", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\";
            });

            //handle message submission
            \$('form[name=message_form]').submit(function (e) {

                e.preventDefault();

                if( \$('#message_form_rating').val() === '' )
                {
                    \$.growl.notice({
                        title: \"Growl\",
                        message: \"Please set rating\"
                    });
                    return false;
                }
                e.submit();
                var form = \$('form[name=\"message_form\"]').serializeArray(); 
                alert( form );

                \$.ajax({
                    type: \"POST\",
                    url: \"";
        // line 177
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("message_save", array("postId" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\",
                    data: {
                        'form': form
                    },
                    success: function (response) {
                        console.log(response);
                        \$('#message_form_div').fadeOut( \"slow\", function() {
                            \$('#contact_form_div').fadeIn(\"slow\");
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(\"AJAX error: \" + textStatus + ' : ' + errorThrown);
                    }
                });

            });
        } );

    </script>
";
        
        $__internal_8bf00290a579f263bf4a7446d72dca9734ff30174dbc64836dbd0271182bb99f->leave($__internal_8bf00290a579f263bf4a7446d72dca9734ff30174dbc64836dbd0271182bb99f_prof);

    }

    public function getTemplateName()
    {
        return "post/post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  356 => 177,  331 => 155,  287 => 118,  282 => 116,  269 => 105,  263 => 104,  253 => 99,  245 => 93,  236 => 90,  230 => 87,  226 => 86,  221 => 85,  213 => 83,  207 => 82,  200 => 80,  195 => 79,  193 => 78,  188 => 77,  186 => 76,  182 => 74,  177 => 73,  172 => 70,  170 => 69,  166 => 67,  158 => 62,  153 => 61,  141 => 52,  136 => 50,  131 => 49,  129 => 48,  122 => 44,  117 => 42,  113 => 41,  98 => 29,  93 => 27,  89 => 26,  77 => 16,  68 => 14,  64 => 13,  58 => 9,  52 => 8,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block title %}
    {{  post.title }} | Item | Online Market for Glass Pipes, Vaporizers, & More At WickedHeady
{% endblock %}

{% block body %}

    <!--IMAGE AREA-->
    <div class=\"col-sm-4 col-lg-4 col-md-4\">
        <div class=\"thumbnail\">
            {% for i in images %}
                <img src=\"{{ asset('uploads/brochures/' ~ i.file) | imagine_filter('my_thumb') }}\" style=\"margin-bottom: 4px\" />
            {%  endfor %}

        </div>
    </div>

    <div class=\"col-sm-8 col-lg-8 col-md-8\">

        <div class=\"thumbnail\">
            <span class=\"glyphicon glyphicon-bookmark\" style=\"top: -4px; left: 4px\"></span>
            <div class=\"caption\">

                <h4>{{ post.title }}</h4>
                <h4>\${{ post.price|number_format(2, '.', ',') }}</h4>
                
                <p>{{ post.description }}</p>
                
                <!--JAVASCRIPT TRIGGER TO SHOW OFFER FORM-->
                <btn type=\"button\" class=\"btn btn-danger pull-right hide\" id=\"hide_offer\" onclick=\"javascript: void(0);\">Submit an Offer</btn>

                <btn type=\"button\" class=\"btn btn-success pull-right\" id=\"submit_offer\" onclick=\"javascript: void(0);\">Submit an Offer</btn>

            </div>
        </div>

        <div class=\"thumbnail\">
            <div class=\"caption\" id=\"contact_form_div\" style=\"display: none \">
                {{ form_start(contact) }}
                {{ form_widget(contact) }}
                <button type=\"submit\" style=\"margin-top: 5px\" class=\"btn btn-default\" formnovalidate>Save</button>
                {{ form_end(contact) }}

            </div>
            <div class=\"caption\" id=\"message_form_div\">
                {% if review is empty %}
                    {{ form_start(message) }}
                    {{ form_widget(message) }}
                    <button type=\"submit\" style=\"margin-top: 5px\" class=\"btn btn-default\" formnovalidate>Save</button>
                    {{ form_end(message) }}
                    <div class=\"ratings\">
                        <div id=\"rateYo\" class=\"pull-left\"></div>
                    </div>
                    <div class=\"hide\">
                        <span id=\"review_title\"></span><br />
                            <span id=\"review_description\"></span>
                    </div>
                {% else %}
                    {{ review.title }}<br />
                    {{ review.message }}
                    <div class=\"ratings\">
                        <div id=\"rateYo\" class=\"pull-left\"></div>
                    </div>
                {% endif %}
            </div>
        </div>                 
        {% if messages is not empty %}
        <div class=\"well\">                      
            <div class=\"caption\">                
 
                    {% for m in messages if m.user.id != 1 %}
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                {% if m.user.id != user_id %}
                                    {% set rate = m.rating %} 
                                    {% set empty = 5-rate %}
                                    {% for i in 1..rate %}
                                        <span class=\"glyphicon glyphicon-star\"></span>
                                    {% endfor %}
                                    {% for e in 1..empty if rate != 5 %}
                                        <span class=\"glyphicon glyphicon-star-empty\"></span>
                                     {% endfor %}
                                    {{m.title}}
                                    <span class=\"pull-right\"> {{ m.tstamp|date('m/d/Y') }}</span>
                                    <p>{{ m.message }}
                                        <span class=\"glyphicon glyphicon-pencil pull-right\" id=\"message_comment \"></span></p>
                                {% endif %}
                            </div>
                        </div> 
                    {% endfor %}

            </div>

        </div>

                {% endif %}
    </div>


{% endblock %}

{% block script %}
  
    <script>
        \$(document).ready( function() {

            //handle rating
            var isMobile = window.matchMedia(\"only screen and (max-width: 760px)\");

            if( !isMobile.matches )
            {
                \$(\"#rateYo\").rateYo({

                    rating: {{ stars|default(4) }},
                    spacing: \"5px\",
                    readOnly: {% if review is empty %} false {% else %} true {% endif %},

                }).on(\"rateyo.set\", function (e, data) {

                    \$('#message_form_rating').val(data.rating);
 

                    \$(\"#rateYo\").rateYo(\"option\", \"readOnly\", \"true\");
                    return false;   

                });

            }
            //handle hiding & showing forms
            \$('#leave_review').click(function (e){
                \$('#message_form_div').fadeOut( \"slow\", function() {
                    \$('#contact_form_div').fadeIn(\"slow\");
                });
            });
 
            \$('#switch_offer').click(function(){

                \$('#hide_offer').toggleClass('hide');
                \$('#submit_offer').toggleClass('hide');
                \$('#contact_form_div').fadeOut( \"slow\", function() {
                    \$('#message_form_div').fadeIn(\"slow\");
                });

            });

            \$('#submit_offer').click(function(){

                \$('#hide_offer').toggleClass('hide');
                \$('#submit_offer').toggleClass('hide');
                \$('#message_form_div').fadeOut( \"slow\", function() {
                    \$('#contact_form_div').fadeIn(\"slow\");
                });
                //window.location=\"{{ path('offer_form', {'id': post.id}) }}\";
            });

            //handle message submission
            \$('form[name=message_form]').submit(function (e) {

                e.preventDefault();

                if( \$('#message_form_rating').val() === '' )
                {
                    \$.growl.notice({
                        title: \"Growl\",
                        message: \"Please set rating\"
                    });
                    return false;
                }
                e.submit();
                var form = \$('form[name=\"message_form\"]').serializeArray(); 
                alert( form );

                \$.ajax({
                    type: \"POST\",
                    url: \"{{ path('message_save', {'postId': post.id}) }}\",
                    data: {
                        'form': form
                    },
                    success: function (response) {
                        console.log(response);
                        \$('#message_form_div').fadeOut( \"slow\", function() {
                            \$('#contact_form_div').fadeIn(\"slow\");
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(\"AJAX error: \" + textStatus + ' : ' + errorThrown);
                    }
                });

            });
        } );

    </script>
{% endblock %}", "post/post.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/post/post.html.twig");
    }
}
