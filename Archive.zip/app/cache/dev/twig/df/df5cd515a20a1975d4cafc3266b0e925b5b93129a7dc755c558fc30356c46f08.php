<?php

/* base.html.twig */
class __TwigTemplate_521d2661ff9921e18f201143e51e0e3c0eb0776c086445e818ad69e955fc153b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'menu' => array($this, 'block_menu'),
            'body' => array($this, 'block_body'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_815c255844ef606321bcbf8a2677aa6ca83d40d243d831451c18526b3c403939 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_815c255844ef606321bcbf8a2677aa6ca83d40d243d831451c18526b3c403939->enter($__internal_815c255844ef606321bcbf8a2677aa6ca83d40d243d831451c18526b3c403939_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/shop-homepage.css"), "html", null, true);
        echo "\" />

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->

    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/growl/stylesheets/jquery.growl.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />
    <!-- Latest compiled and minified CSS -->
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.css\">


</head>

<body>

<!-- Navigation -->
<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">Wicked Heady</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">

                ";
        // line 54
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 55
            echo "                    <li>
                        <a href=\"/profile\">Profile</a>
                    </li>
                    <li>
                        <a href=\"/post\">Posts</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 62
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin");
            echo "\">Admin</a>
                    </li>`
                    <li>
                        <a href=\"";
            // line 65
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
                    </li>
                ";
        } else {
            // line 68
            echo "                    <li>
                        <a href=\"";
            // line 69
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
                    </li>
                    <li>
                        <a href=\"/register\">Sign Up</a>
                    </li>
                ";
        }
        // line 75
        echo "            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<!-- Page Content -->
<div class=\"container\">

    <div class=\"row\">


        <div class=\"col-md-3\">
            <div class=\"list-group\">
                ";
        // line 90
        $this->displayBlock('menu', $context, $blocks);
        // line 93
        echo "            </div>
        </div>

        <div class=\"col-md-9\">

            <div class=\"row\">

                ";
        // line 100
        $this->displayBlock('body', $context, $blocks);
        // line 103
        echo "
            </div>

        </div>

    </div>

</div>
<!-- /.container -->

<div class=\"container\">

    <hr>

    <!-- Footer -->
    <footer>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p>Copyright &copy; Your Website 2014</p>
            </div>
        </div>
    </footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src=\"http://code.jquery.com/jquery-latest.min.js\"></script>

<!-- Latest compiled and minified JavaScript -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.js\"></script>

<!-- Bootstrap Core JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>

<script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/growl/javascripts/jquery.growl.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>


";
        // line 141
        $this->displayBlock('script', $context, $blocks);
        // line 144
        echo "</body>

</html>

";
        
        $__internal_815c255844ef606321bcbf8a2677aa6ca83d40d243d831451c18526b3c403939->leave($__internal_815c255844ef606321bcbf8a2677aa6ca83d40d243d831451c18526b3c403939_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_10bd65215142bcf4e7399b868fe78605b991d5ff07271f61fdd624e1b2bc41ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10bd65215142bcf4e7399b868fe78605b991d5ff07271f61fdd624e1b2bc41ec->enter($__internal_10bd65215142bcf4e7399b868fe78605b991d5ff07271f61fdd624e1b2bc41ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_10bd65215142bcf4e7399b868fe78605b991d5ff07271f61fdd624e1b2bc41ec->leave($__internal_10bd65215142bcf4e7399b868fe78605b991d5ff07271f61fdd624e1b2bc41ec_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b3cf6126b82becce3a0544fced783c7bd43ad995175161ed66f838196cac966e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3cf6126b82becce3a0544fced783c7bd43ad995175161ed66f838196cac966e->enter($__internal_b3cf6126b82becce3a0544fced783c7bd43ad995175161ed66f838196cac966e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b3cf6126b82becce3a0544fced783c7bd43ad995175161ed66f838196cac966e->leave($__internal_b3cf6126b82becce3a0544fced783c7bd43ad995175161ed66f838196cac966e_prof);

    }

    // line 90
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c0de70b96fd75abb200c22896b2103a96115828f9c859c1bb381d2e0e0b7ff3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0de70b96fd75abb200c22896b2103a96115828f9c859c1bb381d2e0e0b7ff3e->enter($__internal_c0de70b96fd75abb200c22896b2103a96115828f9c859c1bb381d2e0e0b7ff3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 91
        echo "                    ";
        $this->loadTemplate("menu.html.twig", "base.html.twig", 91)->display($context);
        // line 92
        echo "                ";
        
        $__internal_c0de70b96fd75abb200c22896b2103a96115828f9c859c1bb381d2e0e0b7ff3e->leave($__internal_c0de70b96fd75abb200c22896b2103a96115828f9c859c1bb381d2e0e0b7ff3e_prof);

    }

    // line 100
    public function block_body($context, array $blocks = array())
    {
        $__internal_fbcf188526e125aaad4fdd001798056771ca570cdaba59a73792566470223b59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbcf188526e125aaad4fdd001798056771ca570cdaba59a73792566470223b59->enter($__internal_fbcf188526e125aaad4fdd001798056771ca570cdaba59a73792566470223b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 101
        echo "
                ";
        
        $__internal_fbcf188526e125aaad4fdd001798056771ca570cdaba59a73792566470223b59->leave($__internal_fbcf188526e125aaad4fdd001798056771ca570cdaba59a73792566470223b59_prof);

    }

    // line 141
    public function block_script($context, array $blocks = array())
    {
        $__internal_51e7027d0f34b023a511e841bf32c0fd396fd558fc79b6b281f797aad8658c34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51e7027d0f34b023a511e841bf32c0fd396fd558fc79b6b281f797aad8658c34->enter($__internal_51e7027d0f34b023a511e841bf32c0fd396fd558fc79b6b281f797aad8658c34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "script"));

        // line 142
        echo "
";
        
        $__internal_51e7027d0f34b023a511e841bf32c0fd396fd558fc79b6b281f797aad8658c34->leave($__internal_51e7027d0f34b023a511e841bf32c0fd396fd558fc79b6b281f797aad8658c34_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  284 => 142,  278 => 141,  270 => 101,  264 => 100,  257 => 92,  254 => 91,  248 => 90,  237 => 12,  225 => 11,  214 => 144,  212 => 141,  206 => 138,  169 => 103,  167 => 100,  158 => 93,  156 => 90,  139 => 75,  128 => 69,  125 => 68,  117 => 65,  111 => 62,  102 => 55,  100 => 54,  71 => 28,  57 => 17,  52 => 15,  48 => 14,  45 => 13,  43 => 12,  39 => 11,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}{% endblock %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap.min.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('css/shop-homepage.css') }}\" />

    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->

    <link href=\"{{ asset('assets/vendor/growl/stylesheets/jquery.growl.css') }}\" rel=\"stylesheet\" type=\"text/css\" />
    <!-- Latest compiled and minified CSS -->
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.css\">


</head>

<body>

<!-- Navigation -->
<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">Wicked Heady</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">

                {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                    <li>
                        <a href=\"/profile\">Profile</a>
                    </li>
                    <li>
                        <a href=\"/post\">Posts</a>
                    </li>
                    <li>
                        <a href=\"{{ path('admin') }}\">Admin</a>
                    </li>`
                    <li>
                        <a href=\"{{ path('fos_user_security_logout') }}\">{{ 'layout.logout'|trans({}, 'FOSUserBundle') }}</a>
                    </li>
                {% else %}
                    <li>
                        <a href=\"{{ path('fos_user_security_login') }}\">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>
                    </li>
                    <li>
                        <a href=\"/register\">Sign Up</a>
                    </li>
                {% endif %}
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<!-- Page Content -->
<div class=\"container\">

    <div class=\"row\">


        <div class=\"col-md-3\">
            <div class=\"list-group\">
                {% block menu %}
                    {% include 'menu.html.twig' %}
                {% endblock %}
            </div>
        </div>

        <div class=\"col-md-9\">

            <div class=\"row\">

                {% block body %}

                {% endblock %}

            </div>

        </div>

    </div>

</div>
<!-- /.container -->

<div class=\"container\">

    <hr>

    <!-- Footer -->
    <footer>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p>Copyright &copy; Your Website 2014</p>
            </div>
        </div>
    </footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src=\"http://code.jquery.com/jquery-latest.min.js\"></script>

<!-- Latest compiled and minified JavaScript -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.2.0/jquery.rateyo.min.js\"></script>

<!-- Bootstrap Core JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>

<script src=\"{{ asset('assets/vendor/growl/javascripts/jquery.growl.js') }}\" type=\"text/javascript\"></script>


{% block script %}

{% endblock %}
</body>

</html>

", "base.html.twig", "/Users/Dan/Web/Symfony/heady-test1/app/Resources/views/base.html.twig");
    }
}
